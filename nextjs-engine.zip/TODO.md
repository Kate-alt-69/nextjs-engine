# Engine Tasks & Bug Tracking

## Critical Bugs

### [BUG-001] SSR Spacing/Sizing Hydration Mismatch
**Issue:** Spacing props (`mt`, `py`, `px`, `h`, etc.) and sizing aliases often fail to render on initial page load. Layout appears "collapsed" or lacks distance until a Next.js Hydration Error occurs, at which point the layout "snaps" into the correct state.

**Root Cause Analysis:**
- The `StyleCollector` Tier System is non-deterministic.
- In development, the server-side process accumulates render counts across multiple requests.
- If a style is promoted to `Group` or `Global` on the server but remains `Local` on a fresh client mount, the `dangerouslySetInnerHTML` for the `__engine_styles__` tag differs.
- When this mismatch occurs, the server-rendered HTML is missing the CSS variable definitions that the client expects, leading to broken initial layouts.

**Proposed Fixes:**
- [ ] Make `StyleCollector` tiers deterministic (e.g., based on a hash or a static registry rather than dynamic render counts). This would be a more robust long-term solution.
- [x] Remove tier comments (`/* ─── local ─── */`, `/* ─── group ─── */`, `/* ─── global ─── */`) from `StyleCollector.ts`'s `collect` method in development to prevent string mismatches during hydration. This addresses the immediate hydration error.
- [ ] Investigate if the collector should be reset or cloned per request on the server to prevent cross-request state pollution.
- [ ] Verify long-form aliases (e.g., `fontSize`, `fontWeight`) are being correctly captured in all tiers.