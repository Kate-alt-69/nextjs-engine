"use client";

// ─────────────────────────────────────────────────────────────────────────────
// Next.js Engine — EngineLink Component
// Strongly-typed production primitive supporting structural props and cprop links.
// ─────────────────────────────────────────────────────────────────────────────

import React, { forwardRef, memo, type ReactNode } from "react";
import { Link as TransitionLink } from "next-view-transitions";
import { usePropStyles } from "../hooks/usePropStyles";
import { useHandler } from "../providers/EngineProvider";
import type { BaseNodeProps } from "../schema/types";

export interface EngineLinkConfig {
	href: string;
	transition?: "page-to-page" | "instant" | string;
	styles?: React.CSSProperties & Record<string, any>;
}

// Intersecting BaseNodeProps safely while adjusting onClick to allow schema string identifiers
export interface EngineLinkProps extends Omit<BaseNodeProps, "onClick"> {
	children?: ReactNode;
	href?: string;
	target?: string;
	content?: string;
	cprop?: any; // Bypasses the strict CpropValue core definition check
	onClick?: string | React.MouseEventHandler<HTMLAnchorElement>;
}

export const EngineLink = memo(
	forwardRef<HTMLAnchorElement, EngineLinkProps>((props, ref) => {
		// Destructure onClick and internal schema variables to prevent them from bleeding into ...restProps
		const {
			href: basicHref,
			target,
			children,
			content,
			className,
			onClick,
			cprop,
			...restProps
		} = props;

		// Extract configuration safely from the behavior configuration tree
		const linkConfig: EngineLinkConfig | undefined = cprop?.link;
		
		// Fallback resolution pipeline cascade
		const targetHref = linkConfig?.href || basicHref || "#";

		// Safeguard properties maps
		const userStyles = cprop?.styles || {};
		const linkStyles = linkConfig?.styles || {};

		const compiledStyles = {
			...userStyles,
			...linkStyles
		};

		// Pass the node configuration props first, and the merged fallback styles object second
		const resolvedClass = usePropStyles(props as any, compiledStyles) as unknown as string;

		// Combine the engine's compiled hash class with the incoming custom user-defined class string
		const finalClassName = [resolvedClass, className].filter(Boolean).join(" ") || undefined;

		const isExternal = targetHref.startsWith("http") || target === "_blank";
		const renderContent = content || children;

		// Resolve named schema event handlers or evaluate incoming functional callbacks safely
		const contextHandler = useHandler(typeof onClick === "string" ? onClick : "");
		
		const handleAnchorClick = (typeof onClick === "function" || contextHandler)
			? (e: React.MouseEvent<HTMLAnchorElement>) => {
				if (typeof onClick === "function") {
					onClick(e);
				} else if (contextHandler) {
					contextHandler(e);
				}
			}
			: undefined;

		// 1. External Routing Pipeline
		if (isExternal) {
			return (
				<a
					ref={ref}
					href={targetHref}
					target={target}
					rel="noopener noreferrer"
					className={finalClassName}
					onClick={handleAnchorClick}
					{...restProps}
				>
					{renderContent}
				</a>
			);
		}

		// 2. Animated Transitions Pipeline (Opt-in only to prevent isolated worker runtime context crashes)
		if (linkConfig?.transition === "page-to-page") {
			return (
				<TransitionLink
					ref={ref}
					href={targetHref}
					className={finalClassName}
					target={target}
					onClick={handleAnchorClick}
					{...restProps}
				>
					{renderContent}
				</TransitionLink>
			);
		}

		// 3. Fallback High-Performance Native Routing (Default layout links, instant triggers, and _not-found page fallbacks)
		return (
			<a
				ref={ref}
				href={targetHref}
				className={finalClassName}
				target={target}
				onClick={handleAnchorClick}
				{...restProps}
			>
				{renderContent}
			</a>
		);
	})
);

EngineLink.displayName = "EngineLink";