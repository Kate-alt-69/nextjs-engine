// ============================================================================
// EngineScrollHash.ts
// ============================================================================

import { EngineScrollMovement } from "./EngineScrollMovement";
import { EngineScrollRuntime } from "./EngineScrollRuntime";
import { EngineScrollPointManager } from "./EngineScrollPointManager";

export class EngineScrollHash {

	public static moveToHash(
		hash: string,
		duration = 550,
	): boolean {

        if (target.startsWith("#")) {
        
        	const registered =
        		EngineScrollPointManager.get(
        			target.slice(1),
        		);
            
        	if (registered) {
            
        		EngineScrollMovement.move(
                
        			registered.point +
                
        			offset,
                
        			duration,
                
        		);
            
        		return true;
            
        	}
        
        	return EngineScrollHash.moveToHash(
            
        		target,
            
        		duration,
            
        	);
        
        }

		const element =
			document.querySelector(hash);

		if (!element) {
			return false;
		}

		const runtime =
			EngineScrollRuntime.get();

		const spacing =
			runtime
				.getState()
				.page
				.pointSpacing;

		const point =
			(
				element.getBoundingClientRect().top +
				window.scrollY
			) /
			spacing;

		EngineScrollMovement.move(
			point,
			duration,
		);

		return true;

	}

}